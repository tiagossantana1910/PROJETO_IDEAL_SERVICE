/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author Tiago Santana
 */
public class Usuario {
    
    private int Usuarioid;
    private String login;
    private String senha;

    /**
     * @return the Usuarioid
     */
    public int getUsuarioid() {
        return Usuarioid;
    }

    /**
     * @param Usuarioid the Usuarioid to set
     */
    public void setUsuarioid(int Usuarioid) {
        this.Usuarioid = Usuarioid;
    }

    /**
     * @return the login
     */
    public String getLogin() {
        return login;
    }

    /**
     * @param login the login to set
     */
    public void setLogin(String login) {
        this.login = login;
    }

    /**
     * @return the senha
     */
    public String getSenha() {
        return senha;
    }

    /**
     * @param senha the senha to set
     */
    public void setSenha(String senha) {
        this.senha = senha;
    }

    /**
     * @return the id
     */
 
    
}
