/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author Tiago Santana
 */
public class Produto {
    private int produtoid;
    private String descricao_prod;
    private int quantidade;
    private double preco;

    /**
     * @return the pridutoid
     */
    public int getProdutoid() {
        return produtoid;
    }

    /**
     * @param produtoid the pridutoid to set
     */
    public void setProdutoid(int produtoid) {
        this.produtoid = produtoid;
    }

    /**
     * @return the descricao_prod
     */
    public String getDescricao_prod() {
        return descricao_prod;
    }

    /**
     * @param descricao_prod the descricao_prod to set
     */
    public void setDescricao_prod(String descricao_prod) {
        this.descricao_prod = descricao_prod;
    }

    /**
     * @return the quantidade
     */
    public int getQuantidade() {
        return quantidade;
    }

    /**
     * @param quantidade the quantidade to set
     */
    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    /**
     * @return the preco
     */
    public double getPreco() {
        return preco;
    }

    /**
     * @param preco the preco to set
     */
    public void setPreco(double preco) {
        this.preco = preco;
    }
    
    
    
}
