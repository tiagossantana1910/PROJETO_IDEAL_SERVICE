/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import conexao.ConnectionFactory;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import modelo.Cliente;

/**
 *
 * @author Tiago Santana
 */
public class ClienteDAO {
    
        public void create(Cliente c){
        
        /*Connection con = ConnectionFactory.getConnection();*/
        java.sql.Connection con = ConnectionFactory.getConnection();
        PreparedStatement stmt = null;
        
        try {
            stmt = con.prepareStatement("INSERT INTO cliente (cpf,nome_cli,data_nasc,telefone,celular,email,cep,logradouro,numero_casa,bairro,cidade,uf)VALUES(?,?,?,?,?,?,?,?,?,?,?,?)");
            stmt.setString(1, c.getCpf());
            stmt.setString(2, c.getNome_cli());
            stmt.setString(3, c.getData_nasc());
            stmt.setString(4, c.getTelefone());
            stmt.setString(5, c.getCelular());
            stmt.setString(6, c.getEmail());
            stmt.setInt(7, c.getCep());
            stmt.setString(8, c.getLogradouro());
            stmt.setInt(9, c.getNumero_casa());
            stmt.setString(10, c.getBairro());
            stmt.setString(11, c.getCidade());
            stmt.setString(12, c.getUf());
            
            stmt.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "Salvo com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao salvar: "+ex);
        }finally{
            ConnectionFactory.closeConnection(con, stmt);
        }   
    }
        
        
    public List<Cliente> read(){
        
        java.sql.Connection con  = ConnectionFactory.getConnection();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        List<Cliente>  clientes = new ArrayList<>();
        
        try {
            stmt = con.prepareStatement("SELECT * FROM cliente");
            rs = stmt.executeQuery();
            
            while (rs.next()){
                
                Cliente cliente  = new Cliente();
                
                cliente.setCpf(rs.getString("cpf"));
                cliente.setNome_cli(rs.getString("nome_cli"));
                cliente.setData_nasc(rs.getString("data_nasc"));
                cliente.setTelefone(rs.getString("telefone"));
                cliente.setCelular(rs.getString("celular"));
                cliente.setEmail(rs.getString("email"));
                cliente.setCep(rs.getInt("cep"));
                cliente.setLogradouro(rs.getString("logradouro"));
                cliente.setNumero_casa(rs.getInt("numero_casa"));
                cliente.setBairro(rs.getString("bairro"));
                cliente.setCidade(rs.getString("cidade"));
                cliente.setUf(rs.getString("uf"));
                clientes.add(cliente);
                
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(ProdutoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            ConnectionFactory.closeConnection(con, stmt, rs);
        }
        
        return clientes;
    }
    public List<Cliente> readForDesc(String nome_cli){
        
        java.sql.Connection con  = ConnectionFactory.getConnection();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        List<Cliente>  clientes = new ArrayList<>();
        
        try {
            stmt = con.prepareStatement("SELECT * FROM cliente WHERE nome_cli LIKE ?");
            stmt.setString(1, "%"+nome_cli+"%");
            
            rs = stmt.executeQuery();
            
            while (rs.next()){
                
                Cliente cliente  = new Cliente();
                
                cliente.setCpf(rs.getString("cpf"));
                cliente.setNome_cli(rs.getString("nome_cli"));
                cliente.setData_nasc(rs.getString("data_nasc"));
                cliente.setTelefone(rs.getString("telefone"));
                cliente.setCelular(rs.getString("celular"));
                cliente.setEmail(rs.getString("email"));
                cliente.setCep(rs.getInt("cep"));
                cliente.setLogradouro(rs.getString("logradouro"));
                cliente.setNumero_casa(rs.getInt("numero_casa"));
                cliente.setBairro(rs.getString("bairro"));
                cliente.setCidade(rs.getString("cidade"));
                cliente.setUf(rs.getString("uf"));
                clientes.add(cliente);
                
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(ProdutoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            ConnectionFactory.closeConnection(con, stmt, rs);
        }
        
        return clientes;
    }
    

    public void delete(Cliente c){
        
        /*Connection con = ConnectionFactory.getConnection();*/
        java.sql.Connection con = ConnectionFactory.getConnection();
        PreparedStatement stmt = null;
        
        try {
            stmt = con.prepareStatement("DELETE FROM cliente WHERE cpf = ?");
            stmt.setString(1, c.getCpf());
            
            stmt.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "Excluido com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir: "+ex);
        }finally{
            ConnectionFactory.closeConnection(con, stmt);
        }
        
        
    }
    
}
